/* ============================================================
   VETERAN ARCHIVES — canonical template.
   Identical for every site. All per-site content lives in data.js
   as window.VA = { site:{...}, veterans:[...] }.
   ============================================================ */
const SITE = (window.VA && window.VA.site) || {};
const veterans = (window.VA && window.VA.veterans) || [];
const IS_QUEUE = SITE.kind === 'queue';

const CONTACT_CLOSE = 'If you have further information about this veteran, please contact the City of Holyoke Veterans Graves Officer at (413) 322-5630 at 310 Appleton Street, 1st Floor, Holyoke, MA 01040.';
const QUEUE_TEXT = 'This veteran has been identified but is still in the research queue — a narrative has not yet been written. The entry is held here until research and grave location are complete.';

(function(){
  var _raw = SITE.title || SITE.name || 'Veteran Archives';
  var _base = _raw.replace(/\s*Veterans?\s+Memorial\s*$/i, '').trim() || _raw;
  window.SITE_BASE = _base;
  var _h1 = document.getElementById('site-title');
  _h1.textContent = _base;
  if (_base !== _raw) {                       // only cemeteries carried "Veterans Memorial"
    var _m = document.createElement('span');
    _m.className = 'mode-label';
    _m.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><line x1="12" y1="1.5" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22.5"/><line x1="1.5" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22.5" y2="12"/></svg><span>Veteran Locator</span>';
    var _nav = document.getElementById('site-nav');
    if (_nav && _nav.parentNode) _nav.parentNode.insertBefore(_m, _nav); else _h1.appendChild(_m);                      // hidden on desktop, shown on phones via CSS
  }
})();
document.getElementById('site-sub').textContent = SITE.address || '';
document.title = (SITE.title || 'Veteran Archives') + ' — Holyoke, MA';

const ERA_COLORS = {
  'Revolutionary War':'#1f3864',
  'Civil War Era':'#8B4513',
  'Spanish-American War':'#CD853F',
  'World War I':'#4682B4',
  'World War II':'#2E8B57',
  'Korean War':'#9370DB',
  'Vietnam':'#DC143C',
  'Cold War':'#5f9ea0',
  'Unknown Era':'#666',
};
const ERA_ORDER = ['Revolutionary War','Civil War Era','Spanish-American War','World War I','World War II','Korean War','Vietnam','Cold War','Unknown Era'];

function normEra(raw) {
  if (!raw) return 'Unknown Era';
  const s = raw.trim();
  if (s.includes('Revolution')) return 'Revolutionary War';
  if (s.includes('Civil')) return 'Civil War Era';
  if (s.includes('Spanish')) return 'Spanish-American War';
  if (s.includes('Vietnam')) return 'Vietnam';
  if (s.includes('World War II')) return 'World War II';
  if (s.includes('World War I')) return 'World War I';
  if (s.includes('Korean')) return 'Korean War';
  if (s.includes('Cold War')) return 'Cold War';
  return 'Unknown Era';
}
function normEras(raw) {
  if (Array.isArray(raw)) {
    const seen = [];
    raw.forEach(r => { const e = normEra(r); if (!seen.includes(e)) seen.push(e); });
    const out = seen.filter(e => e !== 'Unknown Era');
    return out.length ? out.sort((a,b)=>ERA_ORDER.indexOf(a)-ERA_ORDER.indexOf(b)) : ['Unknown Era'];
  }
  return [normEra(raw)];
}
function eraLabel(raw) { return normEras(raw).join(' · '); }
function eraColor(raw) { return ERA_COLORS[normEras(raw)[0]] || '#666'; }

function branchSym(branch) {
  if (!branch) return '✦';
  const b = branch.toUpperCase();
  if (b.includes('NAVY')) return '⚓';
  if (b.includes('MARINE') || b.includes('USMC')) return '🦅';
  if (b.includes('AIR') || b.includes('USAF')) return '✈';
  if (b.includes('COAST')) return '⚑';
  if (b.includes('ARMY')) return '★';
  return '✦';
}

const map = L.map('map', {preferCanvas:true, minZoom:13, maxZoom:20})
  .setView(SITE.center || [42.2043,-72.6162], SITE.zoom || 15);

const satellite = L.tileLayer(
  'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  {attribution:'© Esri', maxNativeZoom:19, maxZoom:20}
);
const street = L.tileLayer(
  'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
  {attribution:'© CARTO', subdomains:'abcd', maxNativeZoom:19, maxZoom:20}
);
const terrain = L.tileLayer(
  'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
  {attribution:'© Esri', maxNativeZoom:19, maxZoom:20}
);
satellite.addTo(map);
L.control.layers({'Satellite':satellite,'Street':street,'Terrain':terrain},{},{position:'topleft'}).addTo(map);

let activeEras = new Set(ERA_ORDER);
let activeDistinction = (typeof window.INIT_DISTINCTION === 'string' && window.INIT_DISTINCTION) || null;
let markerMap = {};
let activeIdx = null;
let searchTerm = '';
let activeMarker = null;

// --- sidebar render state: sort once, render the whole index, let the browser skip what's offscreen ---
let SORTED = null;          // cached sorted index — built once, never re-sorted
let FILTERED = [];          // current filter/search result set
let searchTimer = null;     // debounce handle

// Major distinctions, most prestigious first. Each cemetery builds chips from whichever it actually has.
const DISTINCTION_ORDER = ['Medal of Honor','Distinguished Service Cross','Croix de Guerre','KIA','Purple Heart','Distinguished Service Medal','Cited for Bravery','Air Medal','Silver Star','Bronze Star','French Military Medal','British Military Medal'];
const DISTINCTION_COLORS = {
  'Medal of Honor':'#e6c14a','Distinguished Service Cross':'#9b7ede','Distinguished Service Medal':'#7c6fb0',
  'Silver Star':'#b9c0c7','Bronze Star':'#c99a3a','Air Medal':'#4a9be0','Purple Heart':'#a24bb3',
  'Croix de Guerre':'#4e8f63','KIA':'#c0392b','Cited for Bravery':'#c07a4a','British Military Medal':'#8a7d5b','French Military Medal':'#5b7f8a'
};
const DISTINCTION_SHORT = {};  // spell every distinction out in full
const DISTINCTION_RIBBONS = {
  'Medal of Honor': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="88.0" height="26" fill="#5f77b0"/><polygon points="14.7,6.2 16.3,10.7 21.1,10.9 17.4,13.9 18.6,18.5 14.7,15.8 10.7,18.5 12.0,13.9 8.2,10.9 13.0,10.7" fill="#fff"/><polygon points="29.3,6.2 31.0,10.7 35.8,10.9 32.0,13.9 33.3,18.5 29.3,15.8 25.4,18.5 26.6,13.9 22.9,10.9 27.7,10.7" fill="#fff"/><polygon points="44.0,6.2 45.7,10.7 50.4,10.9 46.7,13.9 48.0,18.5 44.0,15.8 40.0,18.5 41.3,13.9 37.6,10.9 42.3,10.7" fill="#fff"/><polygon points="58.7,6.2 60.3,10.7 65.1,10.9 61.4,13.9 62.6,18.5 58.7,15.8 54.7,18.5 56.0,13.9 52.2,10.9 57.0,10.7" fill="#fff"/><polygon points="73.3,6.2 75.0,10.7 79.8,10.9 76.0,13.9 77.3,18.5 73.3,15.8 69.4,18.5 70.6,13.9 66.9,10.9 71.7,10.7" fill="#fff"/></svg>',
  'Distinguished Service Cross': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="8.8" height="26" fill="#b31942"/><rect x="8.8" width="8.8" height="26" fill="#fff"/><rect x="17.6" width="52.8" height="26" fill="#0a2f66"/><rect x="70.4" width="8.8" height="26" fill="#fff"/><rect x="79.2" width="8.8" height="26" fill="#b31942"/></svg>',
  'Croix de Guerre': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="6.8" height="26" fill="#b31942"/><rect x="6.8" width="13.5" height="26" fill="#2e6b3e"/><rect x="20.3" width="6.8" height="26" fill="#b31942"/><rect x="27.1" width="13.5" height="26" fill="#2e6b3e"/><rect x="40.6" width="6.8" height="26" fill="#b31942"/><rect x="47.4" width="13.5" height="26" fill="#2e6b3e"/><rect x="60.9" width="6.8" height="26" fill="#b31942"/><rect x="67.7" width="13.5" height="26" fill="#2e6b3e"/><rect x="81.2" width="6.8" height="26" fill="#b31942"/></svg>',
  'Purple Heart': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="9.8" height="26" fill="#efe9e3"/><rect x="9.8" width="68.4" height="26" fill="#5b2a86"/><rect x="78.2" width="9.8" height="26" fill="#efe9e3"/></svg>',
  'Distinguished Service Medal': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="6.8" height="26" fill="#0a2f66"/><rect x="6.8" width="33.8" height="26" fill="#b31942"/><rect x="40.6" width="6.8" height="26" fill="#fff"/><rect x="47.4" width="33.8" height="26" fill="#b31942"/><rect x="81.2" width="6.8" height="26" fill="#0a2f66"/></svg>',
  'Cited for Bravery': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="17.6" height="26" fill="#8a6d1f"/><rect x="17.6" width="52.8" height="26" fill="#c9a227"/><rect x="70.4" width="17.6" height="26" fill="#8a6d1f"/><polygon points="44.0,6.2 45.7,10.7 50.4,10.9 46.7,13.9 48.0,18.5 44.0,15.8 40.0,18.5 41.3,13.9 37.6,10.9 42.3,10.7" fill="#fff"/></svg>',
  'Air Medal': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="22.0" height="26" fill="#00308f"/><rect x="22.0" width="11.0" height="26" fill="#f4a41a"/><rect x="33.0" width="22.0" height="26" fill="#00308f"/><rect x="55.0" width="11.0" height="26" fill="#f4a41a"/><rect x="66.0" width="22.0" height="26" fill="#00308f"/></svg>',
  'Silver Star': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="20.3" height="26" fill="#b31942"/><rect x="20.3" width="6.8" height="26" fill="#fff"/><rect x="27.1" width="6.8" height="26" fill="#0a2f66"/><rect x="33.8" width="6.8" height="26" fill="#fff"/><rect x="40.6" width="6.8" height="26" fill="#b31942"/><rect x="47.4" width="6.8" height="26" fill="#fff"/><rect x="54.2" width="6.8" height="26" fill="#0a2f66"/><rect x="60.9" width="6.8" height="26" fill="#fff"/><rect x="67.7" width="20.3" height="26" fill="#b31942"/><polygon points="44.0,6.2 45.7,10.7 50.4,10.9 46.7,13.9 48.0,18.5 44.0,15.8 40.0,18.5 41.3,13.9 37.6,10.9 42.3,10.7" fill="#c0c4c9"/></svg>',
  'Bronze Star': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="6.8" height="26" fill="#fff"/><rect x="6.8" width="27.1" height="26" fill="#b31942"/><rect x="33.8" width="6.8" height="26" fill="#fff"/><rect x="40.6" width="6.8" height="26" fill="#0a2f66"/><rect x="47.4" width="6.8" height="26" fill="#fff"/><rect x="54.2" width="27.1" height="26" fill="#b31942"/><rect x="81.2" width="6.8" height="26" fill="#fff"/><polygon points="44.0,6.2 45.7,10.7 50.4,10.9 46.7,13.9 48.0,18.5 44.0,15.8 40.0,18.5 41.3,13.9 37.6,10.9 42.3,10.7" fill="#cd7f32"/></svg>',
  'French Military Medal': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="12.6" height="26" fill="#2e6b3e"/><rect x="12.6" width="62.9" height="26" fill="#f2c14e"/><rect x="75.4" width="12.6" height="26" fill="#2e6b3e"/></svg>',
  'British Military Medal': '<svg viewBox="0 0 88 26" preserveAspectRatio="none"><rect x="0.0" width="29.3" height="26" fill="#0a2f66"/><rect x="29.3" width="9.8" height="26" fill="#fff"/><rect x="39.1" width="9.8" height="26" fill="#b31942"/><rect x="48.9" width="9.8" height="26" fill="#fff"/><rect x="58.7" width="29.3" height="26" fill="#0a2f66"/></svg>'
};

function ensureRibbonCss(){ if(document.getElementById('va-ribbon-css'))return; var s=document.createElement('style'); s.id='va-ribbon-css'; s.textContent='.fbadge.ribbon-badge{display:inline-flex;align-items:center;gap:5px;background:#f4efe6;color:#241f18;padding:2px 7px 2px 3px;border:1px solid #d8cdb5}.ribbon-badge .rbadge{line-height:0;display:inline-flex}.ribbon-badge .rbadge svg{width:26px;height:10px;display:block;border-radius:1px;outline:.5px solid rgba(0,0,0,.35)}.ribbon-badge .rbadge-name{font-size:.62rem;font-weight:bold}.v-ribbons{display:inline-flex;gap:2px;margin-left:5px;vertical-align:middle}.v-ribbons svg{width:18px;height:7px;display:block;border-radius:1px;outline:.5px solid rgba(0,0,0,.3)}.v-kia-star{color:#d4af37;font-size:11px;line-height:1;vertical-align:middle;text-shadow:0 0 2px rgba(0,0,0,.55)}.leg-ribbon{flex-shrink:0;width:24px;height:9px;line-height:0;display:flex;align-items:center}.leg-ribbon svg{width:24px;height:9px;display:block;border-radius:1px;box-shadow:0 0 2px rgba(0,0,0,.6);outline:.5px solid rgba(0,0,0,.35)}@media (max-width:640px){#legend.in-sheet .leg-ribbon{width:34px;height:12px}#legend.in-sheet .leg-ribbon svg{width:34px;height:12px}.ribbon-badge .rbadge svg{width:30px;height:11px}.v-ribbons svg{width:20px;height:8px}}'; (document.head||document.documentElement).appendChild(s); }
function vetRibbons(v){ if(typeof DISTINCTION_RIBBONS==='undefined')return ''; var out=(v.badges||[]).map(function(b){return DISTINCTION_RIBBONS[b]||(b==='KIA'?'<span class="v-kia-star">\u2605</span>':'');}).filter(Boolean); return out.length?'<span class="v-ribbons">'+out.join('')+'</span>':''; }

function canonBadge(b){ const low=(b||'').toLowerCase(); for(const n of DISTINCTION_ORDER){ if(n.toLowerCase()===low) return n; } return null; }
function vetDistinctions(v){ return (v.badges||[]).map(canonBadge).filter(Boolean); }
function isDistinguished(v){ return vetDistinctions(v).length>0; }
function passesFilters(v){ return normEras(v.era).some(e => activeEras.has(e)) && (!activeDistinction || vetDistinctions(v).includes(activeDistinction)); }

function hasCoords(v){ return v && v.lat!=null && v.lng!=null && !isNaN(v.lat) && !isNaN(v.lng); }

function buildMarkers() {
  Object.values(markerMap).forEach(m => map.removeLayer(m));
  markerMap = {};
  veterans.forEach((v, idx) => {
    if (!passesFilters(v)) return;
    if (!hasCoords(v)) return;
    const color = eraColor(v.era);
    const sym = branchSym(v.branch);
    const dist = isDistinguished(v);
    const isKIA = (v.badges||[]).some(b => (b||'').toLowerCase()==='kia');
    const rim = dist
      ? 'border:2px solid #ffd757;box-shadow:0 0 7px 1px rgba(255,205,70,0.85);'
      : 'border:2px solid rgba(255,255,255,0.65);box-shadow:0 1px 5px rgba(0,0,0,0.8);';
    const pulseCls = activeDistinction ? 'hpulse' : '';
    const star = isKIA ? '<div style="position:absolute;top:-9px;right:-7px;font-size:13px;color:#ffd54a;line-height:1;text-shadow:0 0 3px #000,0 0 6px rgba(255,210,70,0.9);pointer-events:none;">★</div>' : '';
    const prov = (v.geo === 'provisional');
    const dashCol = dist ? '#ffd757' : color;
    const inner = prov
      ? `width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,0.5);border:2px dashed ${dashCol};box-shadow:0 1px 4px rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;font-size:11px;color:${color};cursor:pointer;`
      : `width:26px;height:26px;border-radius:50%;background:${color};${rim}display:flex;align-items:center;justify-content:center;font-size:11px;cursor:pointer;`;
    const icon = L.divIcon({
      className:'',
      html:`<div style="position:relative;width:26px;height:26px;">${star}<div class="${pulseCls}" style="${inner}">${sym}</div></div>`,
      iconSize:[26,26], iconAnchor:[13,13]
    });
    const m = L.marker([v.lat, v.lng], {icon});
    m.on('click', () => selectVet(v, idx));
    m.addTo(map);
    markerMap[idx] = m;
  });
}

function openPopup(v, idx) {
  if (activeMarker) activeMarker.getElement()?.classList.remove('marker-pulse');
  const queued = !((v.narrative||'').trim());
  document.getElementById('pname').textContent = titleName(v.name);
  document.getElementById('pservice').textContent = serviceLine(v);
  const storyEl = document.getElementById('pstory');
  let story = queued ? QUEUE_TEXT : (v.narrative || '');
  if (!queued && story && !story.includes('Veterans Graves Officer at (413) 322-5630')) {
    story += ' ' + CONTACT_CLOSE;                 // the close is ALWAYS part of the narrative
  }
  storyEl.textContent = story;
  storyEl.classList.toggle('queued', queued);

  const srcEl = document.getElementById('psrc');
  srcEl.textContent = v.sourceNote || '';
  srcEl.style.display = v.sourceNote ? 'block' : 'none';
  if (v.sourceNote) storyEl.after(srcEl);          // credits render separately, smaller, BELOW the narrative

  const conEl = document.getElementById('pcontact');
  conEl.textContent = '';
  conEl.style.display = 'none';                     // never render a standalone close

  const photo = document.getElementById('pphoto');
  const ph = document.getElementById('pphoto-ph');
  if (v.photo) { photo.src = v.photo; photo.style.display = 'block'; ph.classList.remove('show'); }
  else if (!hasCoords(v)) { photo.style.display = 'none'; ph.classList.add('show'); }   // queue: pending geo-location
  else { photo.style.display = 'none'; ph.classList.remove('show'); }

  const extEl = document.getElementById('pextra');
  extEl.innerHTML = '';
  (v.extraPhotos||[]).forEach(ep => {
    const link = document.createElement('a');
    link.href = ep.src; link.target = '_blank';
    link.style.cssText = 'display:block;margin-bottom:10px;color:#c8b97a;font-size:0.82rem;text-decoration:none;border:1px solid #444;border-radius:6px;padding:8px 12px;background:#1a1a1a;';
    link.textContent = ep.caption || 'View document';
    extEl.appendChild(link);
  });

  const flagsEl = document.getElementById('pflags');
  flagsEl.innerHTML = '';
  const fs = {'KIA':['#8B0000','#fff'],'Purple Heart':['#7B2D8B','#fff'],'Bronze Star':['#B8860B','#fff'],'Air Medal':['#1a6abf','#fff'],'Female Veteran':['#C71585','#fff'],'Silver Star':['#71797E','#fff'],'Distinguished Service Cross':['#2c1b4d','#fff'],'Croix de Guerre':['#2d5a3d','#fff'],'Died in Service':['#5a3d2d','#fff'],'Medical Officer':['#2d5a5a','#fff'],'Retake Needed':['#333','#c99'],'Cited for Bravery':['#7a4a24','#fff'],'French Military Medal':['#2d4a55','#fff'],'British Military Medal':['#4a442d','#fff'],'Medal of Honor':['#8a6d16','#fff'],'Distinguished Service Medal':['#3d356b','#fff']};
  ensureRibbonCss();
  (v.badges||[]).forEach(f => {
    const rib = (typeof DISTINCTION_RIBBONS!=='undefined') ? DISTINCTION_RIBBONS[f] : null;
    if (rib) {
      const box = document.createElement('span');
      box.className = 'fbadge ribbon-badge';
      box.innerHTML = '<span class="rbadge">'+rib+'</span><span class="rbadge-name">'+f+'</span>';
      flagsEl.appendChild(box); return;
    }
    const [bg,fg] = fs[f]||['#444','#fff'];
    const b = document.createElement('span');
    b.className='fbadge'; b.style.background=bg; b.style.color=fg; b.textContent=f;
    if (f === 'KIA') {
      const st = document.createElement('span');
      st.className = 'kia-badge-star'; st.textContent = '\u2605';
      flagsEl.appendChild(st);
    }
    flagsEl.appendChild(b);
  });

  // Window always sits left of the sidebar, so the index stays clear and scrollable.
  if (hasCoords(v)) {
    const clickedMarker = markerMap[idx];
    if (clickedMarker) { clickedMarker.getElement()?.classList.add('marker-pulse'); activeMarker = clickedMarker; }
    if (!isMobile()) {
      const mapW = map.getContainer().offsetWidth;
      const popupLeft = mapW - 275 - 310;
      const graveTargetX = popupLeft * 0.45;
      const currentCenter = map.project(map.getCenter(), map.getZoom());
      const gravePoint = map.project([v.lat, v.lng], map.getZoom());
      const currentGraveX = gravePoint.x - currentCenter.x + mapW / 2;
      const shiftX = currentGraveX - graveTargetX;
      const newCenter = map.unproject([currentCenter.x + shiftX, currentCenter.y], map.getZoom());
      map.panTo(newCenter, {animate:true, duration:0.7});
    }
  }
  // else: queue / not-yet-located — no pin to pan to; the window still opens in place.

  document.querySelectorAll('.vet-item').forEach(el => el.classList.remove('active'));
  activeIdx = idx;
  // Under a windowed list the row may not exist yet — compute where it lives and
  // scroll there, then draw. Never rely on scrollIntoView for an undrawn row.
  const pos = FILTERED.findIndex(f => f.i === idx);
  if (pos >= 0) {
    const list = document.getElementById('vet-list');
    const top = pos * ROW_H, bot = top + ROW_H;
    if (top < list.scrollTop || bot > list.scrollTop + list.clientHeight) {
      list.scrollTop = Math.max(0, top - list.clientHeight / 2 + ROW_H / 2);
    }
    drawWindow(true);
  }
  document.getElementById('popup').classList.add('show');
  if (window.matchMedia && window.matchMedia('(max-width:640px)').matches) document.body.classList.remove('sheet-open');
}

function closePopup() {
  document.getElementById('popup').classList.remove('show');
  if (activeMarker) { activeMarker.getElement()?.classList.remove('marker-pulse'); activeMarker = null; }
  document.querySelectorAll('.vet-item').forEach(el => el.classList.remove('active'));
  activeIdx = null;
}
map.on('click', () => {
  if (document.getElementById('popup').classList.contains('show')) closePopup();
});

const SUF = /^(Sr|Jr|II|III|IV|MD)\.?$/i;
function sortKey(n){
  if(/^unknown/i.test(n)) return n;   // "Unknown Soldier N" -> sorts under U, in order
  return n.includes(',') ? n.split(',')[0].trim()
    : (() => { const w=n.split(' '); return SUF.test(w[w.length-1])?(w[w.length-2]||w[0]):w[w.length-1]; })();
}
function displayName(n){
  if(/^unknown/i.test(n)) return n;   // show as-is, don't reformat to "N, Unknown Soldier"
  return n.includes(',') ? n
    : (() => { const p=n.trim().split(/\s+/); return p.length>1 ? p[p.length-1]+', '+p.slice(0,-1).join(' ') : n; })();
}

/* --- label normalization: consistent titles + service line across every site --- */
// Military ranks stripped from titles; clergy/civil honorifics (Rev., Fr., Dr., Msgr.) are preserved.
var _RANKS = ['Pvt','Private','Pfc','Cpl','Corporal','Sgt','Sergeant','SSgt','TSgt','MSgt',
  'Lt','Lieut','Lieutenant','Capt','Captain','Maj','Major','Col','Colonel','LtCol',
  'BrigGen','MajGen','Gen','General','Cmdr','Commander','LtCmdr','Ens','Ensign',
  'Adm','Admiral','RAdm','Chief','CPO','SCPO','MCPO','PO1','PO2','PO3','Seaman','SN',
  'Cadet','WO','Sp1','Sp2','Sp3','Sp4','Sp5','Tec4','Tec5'];
function stripRank(n){
  if(!n) return n;
  var s = n.trim();
  s = s.replace(new RegExp(',\\s*(?:'+_RANKS.join('|')+')\\.?\\s*$','i'), '');   // "Last, First, Capt"
  s = s.replace(new RegExp('^(?:'+_RANKS.join('|')+')\\.?\\s+','i'), '');          // "Capt First Last"
  return s.trim();
}
// Canonical branch in Mark's "U.S. Army" style. '' means omit (Military/Unknown/blank).
function normBranch(b){
  if(!b) return '';
  var s = b.trim(); if(!s) return '';
  var core = s.replace(/^U\.?\s?S\.?\s+/i,'').trim();
  if(/^(unknown|military|n\/?a|unknown branch)$/i.test(core) || /^(unknown|military)$/i.test(s)) return '';
  if(/^U\.?\s?S\.?\s+/i.test(s)) return s.replace(/^U\.?\s?S\.?\s+/i,'U.S. ');   // already canonical
  var u = core.toUpperCase();
  if(/^(USNRF|USNR)$|NAVAL RESERVE/.test(u)) return 'U.S. Naval Reserve';
  if(/COAST GUARD RESERVE/.test(u)) return 'U.S. Coast Guard Reserve';
  if(/^USCG$|COAST GUARD/.test(u)) return 'U.S. Coast Guard';
  if(/^USMC$|MARINE/.test(u)) return 'U.S. Marine Corps';
  if(/USAAF|USAAC|ARMY AIR|AIR CORPS|^AAF$/.test(u)) return 'U.S. Army Air Forces';
  if(/^USAF$|AIR FORCE/.test(u)) return 'U.S. Air Force';
  if(/^USN$|^NAVY$/.test(u)) return 'U.S. Navy';
  if(/^ARMY$/.test(u)) return 'U.S. Army';
  if(/MASSACHUSETTS|^MA INFANTRY$|^MA /.test(u)) return core.replace(/^MA\b/i,'Massachusetts');
  return core;   // specialized unit (Ordnance Company, Field Artillery, etc.) — leave as written
}
// Prefer clean `branch`; else the branch portion of a freeform branchLabel (before · or •).
function branchSource(v){
  if(v.branch && v.branch.trim()) return v.branch;
  return (v.branchLabel||'').split(/[·•]/)[0].trim();
}
// The one true service line: "U.S. Army • World War I" (spaced bullet, full era from the era field).
function serviceLine(v){
  return [normBranch(branchSource(v)), eraLabel(v.era)].filter(Boolean).join(' • ');
}
// Title: rank stripped, "Last, First" — identical to the index.
function titleName(n){ return displayName(stripRank(n)); }

// --- index progress checks: small colored check to the right of the name ---
var VET_CHECK_GREEN = {
  beaudoin_raymond_o:1, fd_mackenzie_john:1, muller_joseph_e:1,
  aaron_f_baldwin_cw:1, harper_rev_how_ichabod:1, harper_rev_ludington_daniel:1,
  harper_rev_perkins_elish:1, harper_rev_wood_david:1, dowd__f_mass:1,
  zack_connor_george_s_l:1, kierzek_stanley_p:1, kaster_leonard_l:1,
  anderson_alfred_s:1, begley__d_ww_i_kia:1, blair_joseph_e:1, concannon__l_usaf_ww_ii_korea:1,
  buckley__d_navy_ww_ii:1, davitt__w_ww_i_kia:1,
  fred_k_burnham_cw:1, g_burnham_cw:1, lo_carpenter_cw:1, patrick_j_curran_wwi:1, william_r_dempsey_wwii:1, hugo_dudman_wwi_wwii:1, jno_eveleth_cw:1, arthur_emil_ezold_wwii:1,
  demers_nazaire:1
};
var VET_CHECK_YELLOW = {
  carlton_r_baush_wwi:1, george_a_baush_wwii:1, harold_c_baush_wwii:1,
  zack_desilets_patrick:1,
  altenkirch__a_navy_great_white_fleet:1, ackronis__j_navy_ww_ii:1, allen__w_ct_inf_span_am_war:1, anderson__j_sr_army_ww_ii:1, anderstrom__a_navy_ww_i:1, baldassaro__g_jr_usaf:1, barnett__c_army_ww_ii:1, barnett__j_navy_ww_i:1, barrett__e_army_ww_ii:1, bartley__j_mass_usnrf:1, batchelor__h_army_ww_ii:1, beaulieu__w_f_air_force:1, bedard__e_jr_usmc_vietnam:1,
  abbey__l_army_ww_ii:1, ww2_babyak_john_michael:1, biela_max_e:1, boczon_francis_j:1, brovarek_frank:1, bruder_emil:1, carlow_john:1,
  hillman_merle_c:1, baillargeon__l_military:1, ww2_banas_charles_w:1, fd_batchelor_charles_f:1, zack_blais_albert:1, breton_joseph_j:1, brouillette_george_r:1, zack_brown_henry_a:1, brown_joseph_j:1, brown_kenneth_r:1, burgess_leon_f:1,
  zack_boudreau_alexander:1, elisha_chapin_colonial:1, bogusz_stanley_j:1, chartier_leo_george:1, chatterton_arthur:1, ww2_clark_james_g:1, collins__d_vietnam_bronze_star:1,
  zack_comeau_joseph_e:1, cordeau_harold_w:1, corrigan_john_j:1, coughlin_kirwin:1, croteau_louis_m:1, proteau_rene_a:1, ww2_cuddy_joseph_f:1, harper_cw_cushing_patrick:1, cw_cushing_pat:1, czech_henry_f:1, dalton_john:1,
  harper_rev_chapin_asahel:1, lt_martin_chapin_rev:1, edward_day_rev:1, harper_rev_day_jedediah:1, harper_rev_day_joel:1, harper_rev_day_joel_jr:1, capt_joseph_day_rev:1, robert_day_rev:1, harper_rev_ely_benjamin:1, harper_rev_ely_enoch:1, harper_rev_ely_joseph:1, harper_rev_ely_jube:1, harper_rev_fairfield_levi:1, oswald_f_friedrich:1,
  deffew_percy_w:1, felsentreger__h_t_usmc_vietnam:1, mccormack__g_mass_amb_div_ww_i_ss:1, fd_littlejohn_louis_b:1, owens_david_l:1
};
var VET_CHECK_RED = {
  bousquet_robert_g:1, korea_castro_anthony_j:1,
  bourque_valmore_w:1, harper_cw_boyington_herbert_j:1, cw_boyington_h_j:1, breault_alfred_a:1, korea_brissette_norman:1,
  korea_carroll_william_george:1, korea_charpentier_roland:1, chevrette_albert_e:1, chivas_stanley:1, cleary_james_t:1,
  davidson_william_g:1, dec_walter:1
};
function vetCheck(v){
  var c = VET_CHECK_GREEN[v.id] ? '#16a34a' : (VET_CHECK_YELLOW[v.id] ? '#eab308' : (VET_CHECK_RED[v.id] ? '#dc2626' : ''));
  return c ? '<span class="v-check" style="color:'+c+';font-weight:700;margin-left:24px">\u2713</span>' : '';
}


function sortedList() {
  if (!SORTED) SORTED = veterans.map((v,i)=>({v,i})).sort((a,b)=>
    sortKey(a.v.name).localeCompare(sortKey(b.v.name)) || a.v.name.localeCompare(b.v.name));
  return SORTED;
}

function makeRow(v, idx) {
  const queued = !((v.narrative||'').trim());
  const el = document.createElement('div');
  el.className = 'vet-item' + (idx===activeIdx?' active':'') + (queued?' queued':'');
  el.dataset.i = idx;
  const q = queued ? `<div class="v-badge-q">\u25d4 queue</div>` : '';
  el.innerHTML = `<div class="v-sym" style="color:${eraColor(v.era)}">${branchSym(v.branch)}</div><div style="flex:1;min-width:0"><div class="v-name">${titleName(v.name)}${vetCheck(v)}</div><div class="v-era">${eraLabel(v.era)}${vetRibbons(v)}</div></div>${q}`;
  el.dataset.idx = idx;
  return el;
}

// ---- windowed list -------------------------------------------------------
// Only the rows you can see exist. Above and below them sit two spacers holding
// the exact height of everything not drawn, so the scrollbar is honest and the
// cost of scrolling is the same at 40 names or 40,000.
const ROW_H = 40;            // MUST match .vet-item height in the CSS
const OVERSCAN = 8;          // rows drawn beyond each edge, so a fling doesn't flash blank
let winStart = -1, winEnd = -1, winQueued = false;

function ensureScaffold() {
  const list = document.getElementById('vet-list');
  if (document.getElementById('rows')) return list;
  list.replaceChildren();
  ['pad-top','rows','pad-bot'].forEach(id => {
    const d = document.createElement('div'); d.id = id; list.appendChild(d);
  });
  return list;
}

function drawWindow(force) {
  const list = ensureScaffold();
  const rows = document.getElementById('rows');
  const total = FILTERED.length;
  const visible = Math.ceil(list.clientHeight / ROW_H) + OVERSCAN * 2;
  let first = Math.max(0, Math.floor(list.scrollTop / ROW_H) - OVERSCAN);
  // If the list shortened under us (a filter, a search) the old scroll position can
  // point past the end. Never let that draw an empty window.
  if (first > Math.max(0, total - 1)) first = Math.max(0, total - visible);
  const last = Math.min(total, first + visible);
  if (!force && first === winStart && last === winEnd) return;
  winStart = first; winEnd = last;

  const frag = document.createDocumentFragment();
  for (let n = first; n < last; n++) frag.appendChild(makeRow(FILTERED[n].v, FILTERED[n].i));
  rows.replaceChildren(frag);
  document.getElementById('pad-top').style.height = (first * ROW_H) + 'px';
  document.getElementById('pad-bot').style.height = Math.max(0, (total - last) * ROW_H) + 'px';
  if (activeIdx !== null) {
    const el = rows.querySelector(`.vet-item[data-i="${activeIdx}"]`);
    if (el) el.classList.add('active');
  }
  litLetter();
}

// The rail lights the letter you are actually looking at, and follows the list as it moves.
function litLetter() {
  const rail = document.getElementById('az-rail');
  if (!rail || !rail.children.length || !FILTERED.length) return;
  const list = document.getElementById('vet-list');
  const top = Math.min(FILTERED.length - 1, Math.max(0, Math.round(list.scrollTop / ROW_H)));
  const L = sortKey(FILTERED[top].v.name).trim().charAt(0).toUpperCase();
  if (L === RAIL_LIT) return;
  RAIL_LIT = L;
  rail.querySelectorAll('.az-l').forEach(el => el.classList.toggle('on', el.dataset.l === L));
}

function renderMore() { winStart = winEnd = -1; drawWindow(true); }

// scroll drives the window, coalesced to one draw per frame
document.getElementById('vet-list').addEventListener('scroll', () => {
  if (winQueued) return;
  winQueued = true;
  requestAnimationFrame(() => { winQueued = false; drawWindow(false); });
}, {passive:true});
window.addEventListener('resize', () => drawWindow(true));

function buildSidebar() {
  ensureRibbonCss();
  const list = document.getElementById('vet-list');
  const none = document.getElementById('no-results');
  const term = searchTerm.toLowerCase();
  FILTERED = sortedList().filter(({v}) =>
    passesFilters(v) &&
    (!term || v.name.toLowerCase().includes(term) || (v.branch||'').toLowerCase().includes(term)));
  // Clear the drawn rows ONLY. Wiping #vet-list would destroy pad-top/rows/pad-bot
  // and the windowed list would never draw again.
  document.getElementById('rows').replaceChildren();
  list.scrollTop = 0;
  renderMore();
  buildRail();
  none.style.display = FILTERED.length===0 ? 'block' : 'none';
}

// --- one click handler for the whole index ---
document.getElementById('vet-list').addEventListener('click', e => {
  const row = e.target.closest('.vet-item');
  if (!row) return;
  const idx = +row.dataset.idx;
  const v = veterans[idx];
  if (!v) return;
  selectVet(v, idx);
});

// --- the A-Z rail: the Queue is 3,052 names. Scrolling cannot land on a man; this can. ---
const AZ = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
let AZ_POS = {};
let RAIL_LIT = null;   // the letter currently lit, so we only touch the DOM when it changes
let RAIL_JUMP = 0;     // when the rail last moved the list on purpose
let LETTER_PX = [];    // px position of every letter boundary, rebuilt with the rail   // letter -> first row index in FILTERED, rebuilt on every filter/search

function buildRail() {
  const rail = document.getElementById('az-rail');
  if (!rail) return;
  if (!rail.children.length) {
    const frag = document.createDocumentFragment();
    AZ.forEach(L => {
      const d = document.createElement('div');
      d.className = 'az-l'; d.textContent = L; d.dataset.l = L;
      frag.appendChild(d);
    });
    rail.appendChild(frag);
    const b = document.createElement('div');
    b.id = 'az-bubble'; document.getElementById('sidebar').appendChild(b);
  }
  AZ_POS = {}; RAIL_LIT = null;
  for (let n = 0; n < FILTERED.length; n++) {
    const L = sortKey(FILTERED[n].v.name).trim().charAt(0).toUpperCase();
    if (AZ_POS[L] === undefined) AZ_POS[L] = n;
  }
  rail.querySelectorAll('.az-l').forEach(el => {
    el.classList.toggle('dead', AZ_POS[el.dataset.l] === undefined);
  });
  LETTER_PX = Object.values(AZ_POS).map(p => p * ROW_H).sort((a,b) => a - b);
  litLetter();   // the rail is built after the first draw, so light it now or nothing lights at load
}

// Scrolling is the browser's own, as it was before the sidebar rebuild. No wheel code,
// no momentum, no letter-stop. The A-Z rail is what gives precision on a long list.

function jumpTo(L) {
  const pos = AZ_POS[L];
  if (pos === undefined) return false;
  const list = document.getElementById('vet-list');
  // A row for this man may not exist yet — never scrollIntoView an undrawn row.
  RAIL_JUMP = performance.now();   // tell the letter-stop this move was deliberate
  list.scrollTop = pos * ROW_H;
  drawWindow(true);   // drawWindow lights the letter via litLetter()
  return true;
}

(function railControl(){
  const rail = document.getElementById('az-rail');
  if (!rail) return;
  const bubble = () => document.getElementById('az-bubble');
  let down = false;

  function letterAt(y) {
    const el = document.elementFromPoint(rail.getBoundingClientRect().left + 8, y);
    return (el && el.classList && el.classList.contains('az-l')) ? el : null;
  }
  function go(y) {
    const el = letterAt(y);
    if (!el || el.classList.contains('dead')) return;
    if (jumpTo(el.dataset.l)) {
      const b = bubble();
      if (b) {
        b.textContent = el.dataset.l;
        b.style.display = 'block';
        b.style.top = (el.getBoundingClientRect().top - rail.getBoundingClientRect().top + 3) + 'px';
      }
    }
  }
  rail.addEventListener('pointerdown', e => {
    down = true; rail.setPointerCapture(e.pointerId); go(e.clientY); e.preventDefault();
  });
  rail.addEventListener('pointermove', e => { if (down) go(e.clientY); });
  function up(){ down = false; const b = bubble(); if (b) b.style.display = 'none'; }
  rail.addEventListener('pointerup', up);
  rail.addEventListener('pointercancel', up);
})();

function updateCount() {
  const showing = veterans.filter(passesFilters).length;
  const total = veterans.length;
  const label = IS_QUEUE ? 'In the Research Queue' : 'Documented Veterans';
  document.getElementById('vet-count').textContent =
    showing === total ? `${total} ${label}` : `${showing} of ${total}`;
}

const eraCounts = {};
veterans.forEach(v => { normEras(v.era).forEach(e => { eraCounts[e]=(eraCounts[e]||0)+1; }); });

// Era filters (with counts) live above the names in the sidebar.
const filterDiv = document.getElementById('era-filters');
ERA_ORDER.forEach(era => {
  if (!eraCounts[era]) return;
  const short = era.replace(' Era','').replace('World War ','WW').replace('Korean War','Korea');
  const btn = document.createElement('button');
  btn.className='era-btn selected'; btn.style.background=ERA_COLORS[era]; btn.dataset.era=era;
  btn.innerHTML=`${short} <span class="eb-n">${eraCounts[era]}</span>`;
  btn.addEventListener('click', () => {
    if (activeDistinction) { activeDistinction = null; document.querySelectorAll('.leg-row.dist').forEach(r => r.classList.remove('on')); }
    if (btn.classList.contains('selected')) {
      btn.classList.remove('selected'); activeEras.delete(era);   // darken → those vets fall off
    } else {
      btn.classList.add('selected'); activeEras.add(era);          // re-light → they come back
    }
    buildMarkers(); buildSidebar(); updateCount();
  });
  filterDiv.appendChild(btn);
});

// Distinctions — fill the bottom-left box; hide it entirely if this site has none.
const distCounts = {};
veterans.forEach(v => vetDistinctions(v).forEach(d => distCounts[d] = (distCounts[d]||0)+1));
ensureRibbonCss();
const legDistinct = document.getElementById('leg-distinct');
if (!Object.keys(distCounts).length) {
  document.getElementById('legend').style.display = 'none';
} else {
  DISTINCTION_ORDER.forEach(d => {
    if (!distCounts[d]) return;
    const row = document.createElement('div');
    row.className = 'leg-row dist'; row.dataset.dist = d;
    row.style.setProperty('--dc', DISTINCTION_COLORS[d] || '#888');
    const _rib = (typeof DISTINCTION_RIBBONS!=='undefined') ? DISTINCTION_RIBBONS[d] : null;
    const dotHtml = _rib
      ? `<div class="leg-ribbon">${_rib}</div>`
      : (d==='KIA')
        ? `<div class="leg-sym kia-star">★</div>`
        : `<div class="leg-sym" style="color:${DISTINCTION_COLORS[d]||'#888'};font-size:0.55rem">●</div>`;
    row.innerHTML = `<div class="leg-label">${DISTINCTION_SHORT[d]||d}</div>${dotHtml}<div class="leg-count">${distCounts[d]}</div>`;
    row.addEventListener('click', () => {
      if (activeDistinction === d) { activeDistinction = null; row.classList.remove('on'); }
      else {
        activeDistinction = d;
        document.querySelectorAll('.leg-row.dist').forEach(r => r.classList.remove('on'));
        row.classList.add('on');
        activeEras = new Set(ERA_ORDER);
        document.querySelectorAll('.era-btn').forEach(b => b.classList.add('selected'));
      }
      legDistinct.classList.toggle('filtered', !!activeDistinction);
      buildMarkers(); buildSidebar(); updateCount();
    });
    legDistinct.appendChild(row);
  });
  // arrived with an honor already chosen? light it. If it isn't in this box, drop it
  // rather than show an empty map with no lit row to explain why.
  if (activeDistinction) {
    let found = null;
    legDistinct.querySelectorAll('.leg-row.dist').forEach(r => { if (r.dataset.dist === activeDistinction) found = r; });
    if (found) found.classList.add('on'); else activeDistinction = null;
    legDistinct.classList.toggle('filtered', !!activeDistinction);
  }
  // the word Honors is the way back to all of them
  const head = document.getElementById('leg-head');
  if (head) head.addEventListener('click', () => {
    activeDistinction = null;
    legDistinct.querySelectorAll('.leg-row.dist').forEach(r => r.classList.remove('on'));
    legDistinct.classList.remove('filtered');
    buildMarkers(); buildSidebar(); updateCount();
  });
}

// ===== Site-wide search shared helpers (used by the desktop search box) =====
var _VA_ALL=null, _VA_LOADING=false, _VA_CBS=[];
function vaCurSlug(){ var pp=location.pathname.replace(/\/+$/,'').split('/'); var last=pp[pp.length-1]; return /\.html?$/.test(last)?pp[pp.length-2]:last; }
function vaEsc(s){ var d=document.createElement('div'); d.textContent=s==null?'':s; return d.innerHTML; }
function vaFmtName(n){ if(!n) return n; if(n.indexOf(',')>-1) return n; var p=n.trim().split(/\s+/); return p.length>1?p[p.length-1]+', '+p.slice(0,-1).join(' '):n; }
function vaSiteLabel(s){ return ({calvary:'Calvary',forestdale:'Forestdale',elmwood:'Elmwood','rock-valley':'Rock Valley','smiths-ferry':'Smiths Ferry','research-queue':'Research Queue'})[s]||s; }
function loadAllVets(cb){
  if(_VA_ALL){ cb(_VA_ALL); return; }
  _VA_CBS.push(cb); if(_VA_LOADING) return; _VA_LOADING=true;
  var SITES=['calvary','forestdale','elmwood','rock-valley','smiths-ferry','research-queue'], CUR=vaCurSlug();
  Promise.allSettled(SITES.map(function(slug){
    if(slug===CUR) return Promise.resolve((typeof veterans!=='undefined'?veterans:[]).map(function(v){return {name:v.name,slug:slug,id:v.id};}));
    return fetch('../'+slug+'/data.js',{cache:'no-store'}).then(function(r){ if(!r.ok) throw 0; return r.text(); }).then(function(t){ var sb={}; new Function('window',t)(sb); return ((sb.VA&&sb.VA.veterans)||[]).map(function(v){return {name:v.name,slug:slug,id:v.id};}); });
  })).then(function(rs){
    var all=[]; rs.forEach(function(r){ if(r.status==='fulfilled') all.push.apply(all,r.value); });
    _VA_ALL=all.filter(function(m){return m.id&&m.name;});
    _VA_CBS.forEach(function(f){ f(_VA_ALL); }); _VA_CBS=[];
  });
}
function vaGoMatch(m){
  var CUR=vaCurSlug();
  if(m.slug===CUR){
    var arr=(typeof veterans!=='undefined')?veterans:[], idx=-1;
    for(var i=0;i<arr.length;i++){ if(arr[i].id===m.id){ idx=i; break; } }
    if(idx>-1 && typeof selectVet==='function') selectVet(arr[idx], idx);
  } else { location.href='../'+m.slug+'/index.html?v='+encodeURIComponent(m.id); }
}

// keep the in-place list filter for the current site
document.getElementById('search').addEventListener('input', e => {
  searchTerm = e.target.value;
  clearTimeout(searchTimer);
  searchTimer = setTimeout(buildSidebar, 120);
});
// Enter jumps to the first match ANYWHERE on the site
document.getElementById('search').addEventListener('keydown', e => {
  if (e.key==='Enter') {
    var q=e.target.value.trim().toLowerCase(); if(!q) return;
    loadAllVets(function(all){
      var m=all.filter(function(x){return (x.name||'').toLowerCase().indexOf(q)>-1;})[0];
      if(m) vaGoMatch(m);
    });
  }
});
// site-wide results dropdown under the desktop search box
(function(){
  var input=document.getElementById('search'), top=document.getElementById('sidebar-top');
  if(!input||!top) return;
  top.style.position='relative';
  var box=document.createElement('div'); box.id='site-results'; top.appendChild(box);
  var matches=[];
  function render(){
    var q=input.value.trim();
    if(!q){ box.classList.remove('show'); box.innerHTML=''; return; }
    if(!matches.length){ box.innerHTML='<div class="sr-none">No veteran by that name.</div>'; box.classList.add('show'); return; }
    box.innerHTML=matches.map(function(m,i){ return '<div class="sr-row" data-i="'+i+'"><span class="sr-name">'+vaEsc(vaFmtName(m.name))+'</span><span class="sr-site">'+vaSiteLabel(m.slug)+'</span></div>'; }).join('');
    box.classList.add('show');
  }
  function run(){
    var q=input.value.trim().toLowerCase();
    if(!q){ matches=[]; render(); return; }
    loadAllVets(function(all){
      if(input.value.trim().toLowerCase()!==q) return;
      matches=all.filter(function(m){return (m.name||'').toLowerCase().indexOf(q)>-1;}).slice(0,40);
      render();
    });
  }
  input.addEventListener('input', run);
  input.addEventListener('focus', function(){ if(input.value.trim()) run(); });
  input.addEventListener('blur', function(){ setTimeout(function(){ box.classList.remove('show'); }, 180); });
  box.addEventListener('mousedown', function(e){ var r=e.target.closest('.sr-row'); if(!r) return; e.preventDefault(); var m=matches[+r.dataset.i]; box.classList.remove('show'); if(m) vaGoMatch(m); });
})();

updateCount();
buildMarkers();
buildSidebar();

// Deep-link: ?v=<id> opens that veteran on load — same detail/pulse/highlight as an index click.
(function(){
  var vid = new URLSearchParams(location.search).get('v');
  if(!vid) return;
  var idx = veterans.findIndex(function(v){ return v.id === vid; });
  if(idx < 0) return;
  var match = veterans[idx];
  setTimeout(function(){
    selectVet(match, idx);
  }, 80);
})();

// ===== Field mode behaviour (guards make it a no-op on desktop) =====
(function(){
  var handle = document.getElementById('sheet-handle');
  if (handle) handle.addEventListener('click', function(){ document.body.classList.toggle('sheet-open'); });
  var search = document.getElementById('search');
  if (search) search.addEventListener('focus', function(){ document.body.classList.add('sheet-open'); });
  var popup = document.getElementById('popup');
  if (popup) popup.addEventListener('click', function(e){ if (e.target === popup) closePopup(); });
})();

var _youMarker=null, _youCircle=null, _youCentered=false;
function locateMe(){
  var btn = document.getElementById('locate-me');
  if (!navigator.geolocation){ alert('Location is not available on this device.'); return; }
  if (_watchId !== null){                         // second tap = turn tracking off
    try { navigator.geolocation.clearWatch(_watchId); } catch(e){}
    _watchId = null; _youCentered = false;
    if (_youMarker){ map.removeLayer(_youMarker); _youMarker = null; }
    if (_youCircle){ map.removeLayer(_youCircle); _youCircle = null; }
    if (_guideLine){ map.removeLayer(_guideLine); _guideLine = null; }
    var _db = document.getElementById('dirBar'); if (_db) _db.classList.remove('show');
    if (btn) btn.classList.remove('locating','on');
    stopCompass(); _bearingToGrave = null;
    return;
  }
  if (btn) btn.classList.add('locating');
  startCompass();                                 // request/attach the phone's compass (this tap is the gesture)
  _watchId = navigator.geolocation.watchPosition(function(p){
    var la=p.coords.latitude, lo=p.coords.longitude, ac=p.coords.accuracy;
    if (!_youMarker){
      _youMarker = L.marker([la,lo], {icon:L.divIcon({className:'', html:'<div class="you-dot"></div>', iconSize:[16,16], iconAnchor:[8,8]}), zIndexOffset:1000}).addTo(map);
      _youCircle = L.circle([la,lo], {radius:ac, color:'#4a9be0', weight:1, fillColor:'#4a9be0', fillOpacity:0.12}).addTo(map);
    } else { _youMarker.setLatLng([la,lo]); _youCircle.setLatLng([la,lo]).setRadius(ac); }
    if (btn) { btn.classList.remove('locating'); btn.classList.add('on'); }
    updateDirections();
    if (!_youCentered){
      if (FOCUS) { map.fitBounds(L.latLngBounds([[la,lo],[FOCUS.match.lat, FOCUS.match.lng]]), {maxZoom:19, padding:[70,70]}); }
      else { map.setView([la,lo], Math.max(map.getZoom(), 18)); }
      _youCentered = true;
    }
  }, function(){
    if (btn) btn.classList.remove('locating');
    alert('Could not get your location. Make sure location access is allowed for this site.');
  }, {enableHighAccuracy:true, maximumAge:4000, timeout:15000});
}
(function(){ var b=document.getElementById('locate-me'); if(b) b.addEventListener('click', locateMe); })();

// ===== Field find: focus a grave + live walking directions =====
function isMobile(){ return !!(window.matchMedia && window.matchMedia('(max-width:640px)').matches); }
var FOCUS = null, _guideLine = null, _targetHalo = null, _watchId = null;
var COMPASS = ['N','NE','E','SE','S','SW','W','NW'];
var ARROWS  = ['\u2191','\u2197','\u2192','\u2198','\u2193','\u2199','\u2190','\u2196'];
var FULL    = ['North','Northeast','East','Southeast','South','Southwest','West','Northwest'];
function bearingDeg(la1,lo1,la2,lo2){
  var toR=function(x){return x*Math.PI/180;}, toD=function(x){return x*180/Math.PI;};
  var y=Math.sin(toR(lo2-lo1))*Math.cos(toR(la2));
  var x=Math.cos(toR(la1))*Math.sin(toR(la2))-Math.sin(toR(la1))*Math.cos(toR(la2))*Math.cos(toR(lo2-lo1));
  return (toD(Math.atan2(y,x))+360)%360;
}

// ---- Live compass: rotate the needle so it points the way to WALK ----
// _heading = the direction the phone is facing (0 = true north). When we have it, the
// needle = bearing-to-grave minus heading, so it points at the grave no matter which way
// you turn (straight up = walk straight ahead). No sensor -> fall back to a North-up dial.
var _heading = null, _bearingToGrave = null, _compassOn = false;
function _onOrient(e){
  var h = null;
  if (typeof e.webkitCompassHeading === 'number') { h = e.webkitCompassHeading; }      // iOS: true north, clockwise
  else if (e.absolute === true && typeof e.alpha === 'number') { h = (360 - e.alpha) % 360; } // Android absolute
  if (h != null && !isNaN(h)) { _heading = h; renderCompass(); }
}
function _attachOrient(){
  if (_compassOn) return; _compassOn = true;
  if ('ondeviceorientationabsolute' in window) window.addEventListener('deviceorientationabsolute', _onOrient, true);
  window.addEventListener('deviceorientation', _onOrient, true);
}
function startCompass(){                                   // call from the Guide-me tap (a user gesture)
  if (_compassOn) return;
  if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
    DeviceOrientationEvent.requestPermission().then(function(s){ if (s === 'granted') _attachOrient(); }).catch(function(){});
  } else { _attachOrient(); }
}
function stopCompass(){
  if (!_compassOn) return; _compassOn = false; _heading = null;
  window.removeEventListener('deviceorientationabsolute', _onOrient, true);
  window.removeEventListener('deviceorientation', _onOrient, true);
}
function renderCompass(){
  var arrow = document.getElementById('dir-needle');
  if (!arrow || _bearingToGrave == null) return;
  var rot = (_heading != null) ? (_bearingToGrave - _heading) : _bearingToGrave;
  arrow.style.transform = 'rotate(' + rot + 'deg)';
  var dial = document.getElementById('dir-compass');
  if (dial) dial.classList.toggle('north-up', _heading == null);
}
function ensureDirParts(){
  var bar = document.getElementById('dirBar');
  if (!bar || bar.querySelector('#dir-compass')) return bar;
  bar.innerHTML =
    '<div id="dir-compass"><span id="dir-N">N</span>' +
      '<div id="dir-needle"><svg viewBox="0 0 40 40" width="34" height="34" aria-hidden="true">' +
        '<polygon points="20,3 30,33 20,26 10,33" fill="currentColor"/></svg></div>' +
    '</div><div id="dir-text"></div>';
  return bar;
}
function focusGrave(match, idx){
  FOCUS = {match:match, idx:idx};
  if (_targetHalo){ map.removeLayer(_targetHalo); _targetHalo=null; }
  _targetHalo = L.marker([match.lat, match.lng], {
    icon: L.divIcon({className:'', html:'<div class="target-halo"></div>', iconSize:[54,54], iconAnchor:[27,27]}),
    interactive:true, keyboard:false, zIndexOffset:2000
  }).addTo(map);
  _targetHalo.on('click', function(e){ if(e&&e.originalEvent){e.originalEvent.stopPropagation();} locateMe(); });
  map.setView([match.lat, match.lng], 19, {animate:true, duration:0.8});
  document.getElementById('fb-name').textContent = titleName(match.name);
  document.getElementById('fb-service').textContent =
    serviceLine(match) + (window.SITE_BASE ? ' \u00b7 ' + window.SITE_BASE : '');
  var _fh = document.getElementById('fb-honors');
  if (_fh) _fh.innerHTML = (typeof vetRibbons === 'function') ? vetRibbons(match) : '';
  document.getElementById('findBanner').classList.add('show');
  document.getElementById('dirBar').classList.remove('show');
  document.body.classList.remove('sheet-open');
  document.body.classList.add('grave-focused');
  document.body.classList.remove('vetlist-open');
  setTimeout(function(){ try { map.invalidateSize(); } catch(e){} }, 80);
  if (_youMarker) updateDirections();
}
// On mobile, selecting a veteran (marker tap, index row, in-page search) enters find mode
// instead of the desktop narrative; desktop keeps the narrative.
function selectVet(v, idx){
  if (isMobile() && hasCoords(v)) { focusGrave(v, idx); return; }
  if (hasCoords(v)) { map.flyTo([v.lat, v.lng], 19, {duration:1.0}); setTimeout(function(){ openPopup(v, idx); }, 350); }
  else { openPopup(v, idx); }
}
function clearFocus(){
  FOCUS = null;
  document.getElementById('findBanner').classList.remove('show');
  document.body.classList.remove('grave-focused');
  setTimeout(function(){ try { map.invalidateSize(); } catch(e){} }, 80);
  if (_targetHalo){ map.removeLayer(_targetHalo); _targetHalo=null; }
  if (_guideLine){ map.removeLayer(_guideLine); _guideLine=null; }
  stopCompass(); _bearingToGrave = null;
}
function updateDirections(){
  var bar = document.getElementById('dirBar');
  if (!bar) return;
  if (!FOCUS || !_youMarker){ bar.classList.remove('show'); return; }
  ensureDirParts();
  var txt = document.getElementById('dir-text');
  var comp = document.getElementById('dir-compass');
  var _dv = document.getElementById('fb-drive');
  var you = _youMarker.getLatLng(), g = L.latLng(FOCUS.match.lat, FOCUS.match.lng);
  var feet = Math.round(you.distanceTo(g) * 3.28084);
  if (feet <= 15){                                          // standing on it
    _bearingToGrave = null;
    if (comp) comp.style.display = 'none';
    txt.innerHTML = '<span class="dir-here">You\u2019re here \u2014 look around you</span>';
    if (_dv) _dv.style.display = 'none';
  } else if (feet > 2000){                                  // too far to walk a bearing -> road directions
    _bearingToGrave = null;
    if (comp) comp.style.display = 'none';
    txt.innerHTML = '<span class="dir-dist">' + (feet/5280).toFixed(1) + ' <small>mi</small></span>' +
                    '<span class="dir-word">away \u2014 tap Drive there</span>';
    if (_dv) _dv.style.display = 'block';
  } else {                                                  // walking range: compass + distance
    _bearingToGrave = bearingDeg(you.lat, you.lng, g.lat, g.lng);
    var i = Math.round(_bearingToGrave/45) % 8;
    if (comp) comp.style.display = '';
    txt.innerHTML = '<span class="dir-word">Head ' + FULL[i] + '</span>' +
                    '<span class="dir-dist">' + feet + ' <small>ft</small></span>';
    if (_dv) _dv.style.display = 'none';
    renderCompass();
  }
  bar.classList.add('show');
  if (!_guideLine){ _guideLine = L.polyline([you, g], {color:'#ffd757', weight:3, opacity:0.85, dashArray:'6,7'}).addTo(map); }
  else _guideLine.setLatLngs([you, g]);
}
(function(){
  var g=document.getElementById('fb-guide');   if(g) g.addEventListener('click', locateMe);
  var d=document.getElementById('fb-details'); if(d) d.addEventListener('click', function(){ if(FOCUS) openPopup(FOCUS.match, FOCUS.idx); });
  var c=document.getElementById('fb-close');   if(c) c.addEventListener('click', clearFocus);
})();

// Site-to-site navigation: "Next Site" link + swipe on the header bar.
// Swipe is bound to the header only — binding it to the map would break map panning.
(function(){
  var CHAIN = ['calvary','elmwood','forestdale','rock-valley','smiths-ferry','research-queue','honor-roll'];
  var parts = location.pathname.replace(/\/index\.html$/,'').split('/').filter(Boolean);
  var cur = parts[parts.length-1] || '';
  var i = CHAIN.indexOf(cur);
  var next = CHAIN[(i + 1) % CHAIN.length];
  var prev = (i > 0) ? CHAIN[i-1] : null;
  var nx = document.getElementById('nav-next');
  if (nx) nx.href = '../' + next + '/index.html';

  var hdr = document.getElementById('header'), x0=null, y0=null;
  function isPhone(){ return !!(window.matchMedia && window.matchMedia('(max-width:640px)').matches); }
  if (hdr) {
    hdr.addEventListener('touchstart', function(e){
      if (!isPhone() || e.touches.length !== 1) { x0=null; return; }
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY;
    }, {passive:true});
    hdr.addEventListener('touchend', function(e){
      if (x0 === null) return;
      var t = e.changedTouches[0], dx = t.clientX - x0, dy = t.clientY - y0;
      x0 = null;
      if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx) * 0.7) return;
      if (dx < 0) location.href = '../' + next + '/index.html';
      else if (prev) location.href = '../' + prev + '/index.html';
      else location.href = '../index.html';
    }, {passive:true});
  }
})();

// Sun Mode: high-contrast daylight view. Manual toggle (Safari blocks light-sensor access).
(function(){
  var btn = document.getElementById('sun-toggle'); if(!btn) return;
  var wl = null;
  function lock(){ try { if ('wakeLock' in navigator) navigator.wakeLock.request('screen').then(function(s){ wl=s; }).catch(function(){}); } catch(e){} }
  function unlock(){ try { if (wl) { wl.release(); wl=null; } } catch(e){} }
  function set(on){
    document.body.classList.toggle('sun', on);
    try { sessionStorage.setItem('va-sun', on ? '1' : '0'); } catch(e){}
    if (on) lock(); else unlock();
  }
  try { if (sessionStorage.getItem('va-sun') === '1') set(true); } catch(e){}
  btn.addEventListener('click', function(){ set(!document.body.classList.contains('sun')); });
  document.addEventListener('visibilitychange', function(){
    if (!document.hidden && document.body.classList.contains('sun')) lock();
  });
})();

// Keep the map buttons clear of the bottom sheet no matter how tall it gets.
function syncFieldButtons(){
  var sb = document.getElementById('sidebar'), h = 0;
  if (sb && !document.body.classList.contains('grave-focused')
         && !document.body.classList.contains('sheet-open')) h = sb.offsetHeight || 0;
  document.documentElement.style.setProperty('--sheet-h', h + 'px');
}
(function(){
  syncFieldButtons();
  window.addEventListener('resize', syncFieldButtons);
  window.addEventListener('load', syncFieldButtons);
  var hd = document.getElementById('sheet-handle');
  if (hd) hd.addEventListener('click', function(){ setTimeout(syncFieldButtons, 60); });
  setTimeout(syncFieldButtons, 400);
})();

// Beyond walking range, hand off to the phone's own maps app for turn-by-turn road directions.
(function(){
  var acts = document.querySelector('.fb-actions'); if (!acts) return;
  var d = document.createElement('button');
  d.id = 'fb-drive'; d.type = 'button'; d.textContent = 'Drive there';
  d.style.display = 'none';
  d.addEventListener('click', function(){
    if (!FOCUS || !FOCUS.match) return;
    var la = FOCUS.match.lat, lo = FOCUS.match.lng;
    if (la == null || lo == null) return;
    var ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
    var url = ios
      ? 'https://maps.apple.com/?daddr=' + la + ',' + lo + '&dirflg=d'
      : 'https://www.google.com/maps/dir/?api=1&destination=' + la + ',' + lo + '&travelmode=driving';
    window.open(url, '_blank');
  });
  acts.appendChild(d);
})();

/* ---- MOBILE MAP REDESIGN wiring (phones only) ---- */
(function(){
  if (!(window.matchMedia && window.matchMedia('(max-width:640px)').matches)) return;
  var nav = document.getElementById('site-nav');
  var ml  = document.querySelector('#header .mode-label');
  if (nav && ml) nav.insertBefore(ml, nav.firstChild);
  if (ml) ml.addEventListener('click', function(){ document.body.classList.toggle('vetlist-open'); });
  if (nav){
    var back = nav.querySelector('.nav-back'); if (back){ back.textContent = 'Return to Landing Page'; }
    var next = nav.querySelector('.nav-next'); if (next){ next.style.display = 'none'; }
  }
  var g = document.getElementById('fb-guide');
  if (g) g.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="vertical-align:middle;margin-right:5px"><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><line x1="12" y1="1.5" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22.5"/><line x1="1.5" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22.5" y2="12"/></svg>Veteran Locator';
  var _fbs = document.getElementById('fb-service');
  if (_fbs && !document.getElementById('fb-honors')) {
    var _fhx = document.createElement('div'); _fhx.id = 'fb-honors';
    _fbs.parentNode.insertBefore(_fhx, _fbs.nextSibling);
  }
  /* list closes only when a veteran is selected, or by tapping Veteran Locator again */

  /* 2: open the veteran list with the map (unless deep-linking straight to a grave) */
  if (!/[?&]v=/.test(location.search)) document.body.classList.add('vetlist-open');

  /* 3: site-wide veteran search inside the drawer — finds a vet on ANY page */
  (function(){
    var sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    var res  = document.createElement('div'); res.id = 'mob-search-res';
    var wrap = document.createElement('div'); wrap.id = 'mob-search-wrap';
    wrap.innerHTML = '<input id="mob-search" type="search" autocomplete="off" autocorrect="off" autocapitalize="off" placeholder="Find a veteran \u2014 any site\u2026">';
    sidebar.insertBefore(res, sidebar.firstChild);
    sidebar.insertBefore(wrap, sidebar.firstChild);
    var input = document.getElementById('mob-search');

    var SITES  = ['calvary','forestdale','elmwood','rock-valley','smiths-ferry','research-queue'];
    var LABELS = {calvary:'Calvary',forestdale:'Forestdale',elmwood:'Elmwood','rock-valley':'Rock Valley','smiths-ferry':'Smiths Ferry','research-queue':'Research Queue'};
    var pp = location.pathname.replace(/\/+$/,'').split('/'); var lastp = pp[pp.length-1];
    var CUR = /\.html?$/.test(lastp) ? pp[pp.length-2] : lastp;
    var INDEX = null, loading = false, matches = [];

    function fmt(n){ if(!n) return n; if(n.indexOf(',')>-1) return n; var p=n.trim().split(/\s+/); return p.length>1 ? p[p.length-1]+', '+p.slice(0,-1).join(' ') : n; }
    function esc(s){ var d=document.createElement('div'); d.textContent = s==null?'':s; return d.innerHTML; }

    function load(){
      if (INDEX || loading) return; loading = true;
      input.setAttribute('placeholder','Loading veterans\u2026');
      Promise.allSettled(SITES.map(function(slug){
        if (slug===CUR) return Promise.resolve((typeof veterans!=='undefined'?veterans:[]).map(function(v){return {name:v.name,slug:slug,id:v.id};}));
        return fetch('../'+slug+'/data.js',{cache:'no-store'}).then(function(r){ if(!r.ok) throw 0; return r.text(); }).then(function(t){ var sb={}; new Function('window',t)(sb); return ((sb.VA&&sb.VA.veterans)||[]).map(function(v){return {name:v.name,slug:slug,id:v.id};}); });
      })).then(function(rs){
        var all=[]; rs.forEach(function(r){ if(r.status==='fulfilled') all.push.apply(all,r.value); });
        INDEX = all.filter(function(m){ return m.id && m.name; });
        input.setAttribute('placeholder','Find a veteran \u2014 any site\u2026');
        search();
      });
    }
    function go(m){
      if (m.slug===CUR){
        var arr = (typeof veterans!=='undefined')?veterans:[], idx=-1;
        for (var i=0;i<arr.length;i++){ if(arr[i].id===m.id){ idx=i; break; } }
        input.value=''; matches=[]; render();
        document.body.classList.remove('vetlist-open');
        if (idx>-1 && typeof selectVet==='function') selectVet(arr[idx], idx);
      } else {
        location.href = '../'+m.slug+'/index.html?v='+encodeURIComponent(m.id);
      }
    }
    function render(){
      if (!matches.length){
        res.innerHTML = input.value.trim() ? '<div class="mob-none">No veteran by that name.</div>' : '';
        var on = !!input.value.trim(); res.classList.toggle('show', on); document.body.classList.toggle('mob-searching', on);
        return;
      }
      res.innerHTML = matches.map(function(m,i){ return '<div class="mob-res" data-i="'+i+'"><span class="mob-res-name">'+esc(fmt(m.name))+'</span><span class="mob-res-site">'+(LABELS[m.slug]||m.slug)+'</span></div>'; }).join('');
      res.classList.add('show'); document.body.classList.add('mob-searching');
    }
    function search(){
      var t = input.value.trim().toLowerCase();
      matches = (INDEX && t) ? INDEX.filter(function(m){ return (m.name||'').toLowerCase().indexOf(t)>-1; }).slice(0,30) : [];
      render();
    }
    input.addEventListener('focus', load);
    input.addEventListener('input', function(){ if(!INDEX) load(); search(); });
    res.addEventListener('click', function(e){ var r=e.target.closest('.mob-res'); if(!r) return; var m=matches[+r.dataset.i]; if(m) go(m); });
  })();
})();
